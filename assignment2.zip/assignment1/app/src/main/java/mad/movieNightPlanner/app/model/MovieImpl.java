package mad.movieNightPlanner.app.model;



public class MovieImpl extends AbstractMovie  {


    public MovieImpl(String id, String title, String year, String poster) {
        super(id, title, year, poster);

    }


}
