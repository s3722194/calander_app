package mad.movieNightPlanner.app.model;

public interface Movie {

   String getTitle();

    String getYear();

   String getPoster();

    String getID();
}
